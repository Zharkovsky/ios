//
//  ViewController.swift
//  FaceIt
//
//  Created by xcode on 30.10.2017.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class FaceViewController:
        UIViewController{
    
    @IBOutlet weak var faceView: FaceView!
    
    var expression = FacialExpression(eyes: .Open, eyeBrows: .Normal, mouth: .Smile)
    {
        didSet {
            updateUI()
        }
    }
    
    private var mouthCurvatures = [FacialExpression.Mouth.Frown: -1.0, .Grin: 0.5, .Smile: 1.0, .Smirk: -0.5, .Neutral: 0.0]
    
    private func updateUI() {
        switch expression.eyes {
        case .Open: faceView.eyesOpen = true
        case .Closed: faceView.eyesOpen = false
        case .Squinting: faceView.eyesOpen = false
        }
        faceView.mouthCurvature = mouthCurvatures[expression.mouth] ?? 0.0
//        faceView.eyeBrowTilit = eyeBrowTilits[expression.eyeBrows] ?? 0.0
    }
}

