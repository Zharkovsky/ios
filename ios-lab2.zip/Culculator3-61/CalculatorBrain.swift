//
//  File.swift
//  Culculator3-61
//
//  Created by xcode on 11.09.17.
//  Copyright © 2017 VSU. All rights reserved.
//
// 44

import Foundation

func factorial(digit: Double) -> Double {
    var res: Double = 1
    var i: Double = 2
    
    while i <= digit {
        res *= i
        i += 1
    }
    
    return res
}

func delete(digit: Double) -> Double {
    return 0
}

class CalculatorBrain {
    
    private var accumulator = 0.0
    
    func setOperand(operand: Double){
        accumulator = operand
    }
    
    private var operations: Dictionary<String, Operation> = [
        "π" : Operation.Constant(.pi),
        "e" : Operation.Constant(M_E),
        "√" : Operation.UnaryOperation(sqrt),
        "х²" : Operation.UnaryOperation({ $0 * $0 }),
        "x⁻¹" : Operation.UnaryOperation({ 1/$0 }),
        "x!"  : Operation.UnaryOperation(factorial),
        "cos" : Operation.UnaryOperation(cos),
        "sin" : Operation.UnaryOperation(sin),
        "tan" : Operation.UnaryOperation(tan),
        "sin⁻¹" : Operation.UnaryOperation(asin),
        "cos⁻¹" : Operation.UnaryOperation(acos),
        "tan⁻¹" : Operation.UnaryOperation(atan),
        "ln" : Operation.UnaryOperation(log),
        "±": Operation.UnaryOperation({ -$0 }),
        "*" : Operation.BinaryOperation({ $0 * $1 }),
        "/" : Operation.BinaryOperation({ $0 / $1 }),
        "+" : Operation.BinaryOperation({ $0 + $1 }),
        "-" : Operation.BinaryOperation({ $0 - $1 }),
        "C" : Operation.UnaryOperation(delete),
        "=" : Operation.Equals,
    ]
    
    private enum Operation{
        case Constant(Double)
        case UnaryOperation((Double) -> Double)
        case BinaryOperation((Double, Double) -> Double)
        case Equals
    }
    
    func perfomOperation(symbol: String){
        if let operation = operations[symbol] {
            switch operation {
            case .Constant(let value) :
                accumulator = value
            case .UnaryOperation(let function) :
                executePendingBinaryOperation()
                accumulator = function(accumulator)
            case .BinaryOperation(let function) :
                executePendingBinaryOperation()
                pending = PendingBinaryOperationInfo(binaryFunc: function, firstOperand: accumulator)
            case .Equals :
                executePendingBinaryOperation()
            }
        }
    }
    
    private var pending: PendingBinaryOperationInfo?
    
    private func executePendingBinaryOperation()
    {
        if pending != nil{
            accumulator = pending!.binaryFunc(pending!.firstOperand, accumulator)
            pending = nil
        }
    }
    
    private struct PendingBinaryOperationInfo {
        var binaryFunc: (Double, Double) -> Double
        var firstOperand: Double
    }
    
    var result: Double {
        get {
            return accumulator
        }
    }
}
