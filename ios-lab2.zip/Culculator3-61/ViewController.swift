//
//  ViewController.swift
//  Culculator3-61
//
//  Created by xcode on 04.09.17.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var History: UILabel!
    
    @IBOutlet private weak var display: UILabel!
    private var userIsInTyping: Bool = false
    private var dotIsUsed: Bool = false
    private var isOneNumber: Bool = true
    
    
    private var displayValue: Double {
        get{
            return Double(display.text!)!
        }
        set{
            display.text = String(newValue)
        }
    }
    
    @IBAction private func touchDigit(sender: UIButton) {
        let digit = sender.currentTitle!
        
        if userIsInTyping {
            let currentDisplay = display!.text!
            let isDot = (digit == "." && dotIsUsed == false)
            if(digit != "." || isDot){
                display.text! = currentDisplay + digit
            }
            if isDot { dotIsUsed = true }
        }
        else{
            display.text! = digit
            if(digit == "." && dotIsUsed == false){
                display.text! = "0."
                dotIsUsed = true;
            }
        }
        userIsInTyping = true
        
        History.text = History.text! + sender.currentTitle!;
    }
    
    private var brain: CalculatorBrain = CalculatorBrain()
    
    @IBAction private func mathOperation(sender: UIButton) {
        
        if userIsInTyping {
            brain.setOperand(operand: displayValue)
            dotIsUsed = false
        }
        
        userIsInTyping = false
        if let mathSymbol = sender.currentTitle {
            brain.perfomOperation(symbol: mathSymbol)
            if mathSymbol == "=" { dotIsUsed = false }
        }
        
        if(sender.currentTitle == "+" || sender.currentTitle == "-")
        {
            History.text = History.text! + sender.currentTitle!
        }
        else if(sender.currentTitle == "*" || sender.currentTitle == "/")
        {
            History.text = "(" + History.text! + ")" + sender.currentTitle!
        }
        else if(sender.currentTitle == "π")
        {
            History.text = History.text! + String(Double.pi)
        }
        else if(sender.currentTitle == "e")
        {
            History.text = History.text! + String(Double.Exponent())
        }
        else if (sender.currentTitle == "x⁻¹" || sender.currentTitle == "x!")
        {
            let temp = sender.currentTitle?.replacingOccurrences(of: "x", with: "")
            History.text = "(" + History.text! + ")" + temp!
        }
        else if(sender.currentTitle == "х²" )
        {
            History.text = "(" + History.text! + ")²"
        }
        else if(sender.currentTitle == "√" )
        {
            History.text = "√(" + History.text! + ")"
        }
        else if(sender.currentTitle == "cos" || sender.currentTitle == "sin" || sender.currentTitle == "tan"
            || sender.currentTitle == "sin⁻¹" || sender.currentTitle == "cos⁻¹" || sender.currentTitle == "tan⁻¹" || sender.currentTitle == "ln")
        {
            History.text = sender.currentTitle! + "(" + History.text! + ")"
        }
        else if (sender.currentTitle == "±")
        {
            History.text = "-(" + History.text! + ")"
        }
        else if(sender.currentTitle == "C")
        {
            History.text = ""
        }
        
        displayValue = brain.result
    }
    
    //===== Lab2 ====//
    
    private var usingM: Bool = false
    
    @IBAction func save() {
    }
    
    @IBAction func restore() {
    }
    
    @IBAction func useM(_ sender: Any) {
        usingM = true
        History.text = History.text! + "M"
        display.text = "M"
    }
    
    @IBAction func enterM(_ sender: Any) {
        M = Double(display.text!)!
        test()
        display.text = ""
    }
    
    private var M: Double = 0.0
    
    private func test(){
        let dictionary = ["M": M]

        let formula = History.text!
        if(!formula.isEmpty)
        {
            if let result = formula.expression.expressionValue(with: dictionary, context: nil) as? Int
            {
                print(result)
            }
        }
    }
}

extension String {
    var expression: NSExpression {
        return NSExpression(format: self)
    }
}

