//
//  ViewController.swift
//  Culculator3-61
//
//  Created by xcode on 04.09.17.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet private weak var display: UILabel!
    private var userIsInTyping: Bool = false
    private var dotIsUsed: Bool = false
    
    private var displayValue: Double {
        get{
            return Double(display.text!)!
        }
        set{
            display.text = String(newValue)
        }
    }
    
    @IBAction private func touchDigit(sender: UIButton) {
        let digit = sender.currentTitle!
        
        if userIsInTyping {
            let currentDisplay = display!.text!
            let isDot = (digit == "." && dotIsUsed == false)
            if(digit != "." || isDot){
                display.text! = currentDisplay + digit
            }
            if isDot { dotIsUsed = true }
        }
        else{
            display.text! = digit
            if(digit == "." && dotIsUsed == false){
                display.text! = "0."
                dotIsUsed = true;
            }
        }
        
        userIsInTyping = true
        
    }
    
    private var brain: CalculatorBrain = CalculatorBrain()
    
    @IBAction private func mathOperation(sender: UIButton) {
        if userIsInTyping {
            brain.setOperand(displayValue)
            dotIsUsed = false
        }
        
        userIsInTyping = false
        if let mathSymbol = sender.currentTitle {
            brain.perfomOperation(mathSymbol)
            if mathSymbol == "=" { dotIsUsed = false }
        }
        
        displayValue = brain.result
    }
}

