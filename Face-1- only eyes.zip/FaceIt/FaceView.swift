//
//  FaceView.swift
//  FaceIt
//
//  Created by xcode on 30.10.2017.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class FaceView: UIView {
    
    var scale: CGFloat = 0.9

    var skullRadius: CGFloat{ return (min(bounds.size.width, bounds.size.height)/2) }
    var skullCenter: CGPoint{ return CGPoint(x: bounds.midX, y: bounds.midY)}
    
    private struct Ratios {
        static let
        SkullRadiusToEyeOffset:
            CGFloat = 3
        static let
        SkullRadiusToEyeRadius:
            CGFloat = 10
        static let
        SkullRadiusToMouthWidth:
            CGFloat = 1
        static let
        SkullRadiusToMouthHeight:
            CGFloat = 3
        static let
        SkullRadiusToMouthOffset:
            CGFloat = 3
    }
    
    private enum Eye {
        case Left
        case Right
    }
    
    private func pathForEye(eye: Eye)->
        UIBezierPath{
            let eyeRadius = skullRadius/Ratios.SkullRadiusToEyeRadius
            let eyeCenter = getEyeCenter(eye: eye)
            return
                pathForCircleCenteredAtPoint(midPoint: eyeCenter, widthRadios: eyeRadius)
        }
    
    
    private func getEyeCenter(eye: Eye)->
        CGPoint {
            let eyeOffset = skullRadius / Ratios.SkullRadiusToEyeOffset
            var eyeCenter = skullCenter
            eyeCenter.y -= eyeOffset
            switch eye {
            case.Left:
                eyeCenter.x -= eyeOffset
            case .Right:
                eyeCenter.x += eyeOffset
            }
            return eyeCenter
        }
    
    private func pathForCircleCenteredAtPoint(midPoint: CGPoint, widthRadios radius: CGFloat) -> UIBezierPath{
        let path = UIBezierPath(arcCenter:midPoint, radius: radius, startAngle: 0.0, endAngle: CGFloat(2*M_PI), clockwise: false)
        path.lineWidth = 5.0
        return path
    }
    
    override func draw(_ rect: CGRect) {
        
        UIColor.blue.set()
        pathForCircleCenteredAtPoint(midPoint: skullCenter, widthRadios: skullRadius).stroke()
        pathForEye(eye: .Left).stroke()
        pathForEye(eye: .Right).stroke()
        
    }
    
    

}
