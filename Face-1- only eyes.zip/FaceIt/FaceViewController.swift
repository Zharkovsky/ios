//
//  ViewController.swift
//  FaceIt
//
//  Created by xcode on 30.10.2017.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class FaceViewController:
        UIViewController{
    
    
    
}

