//
//  EmotionsViewController.swift
//  FaceIt
//
//  Created by xcode on 04.12.2017.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class EmotionsViewController: UIViewController {
    
    private let emotionalFace: Dictionary<String, FaceExpression> = [
        "angry" : FaceExpression(eyes: .Closed, eyeBrows: .Normal, mouth: .Frown),
        "happy" : FaceExpression(eyes: .Open, eyeBrows: .Relaxed, mouth: .Smile),
        "worried" : FaceExpression(eyes: .Closed, eyeBrows: .Normal, mouth: .Neutral),
        "mishievious" : FaceExpression(eyes: .Closed, eyeBrows: .Normal, mouth: .Smirk),
    ]
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destinationvc = segue.destination
        if let navcon = destinationvc as? UINavigationController {
            destinationvc = navcon.visibleViewController ?? destinationvc
        }
        
        if let facevc = destinationvc as? FaceViewController {
            if let identifier = segue.identifier {
                if let expression = emotionalFace[identifier]{
                    facevc.expression = expression
                    
                    if let sendingButt = sender as? UIButton {
                        facevc.navigationItem.title = sendingButt.currentTitle
                    }
                }
            }
        }
    }
}
