//
//  ViewController.swift
//  FaceIt
//
//  Created by xcode on 30.10.2017.
//  Copyright © 2017 VSU. All rights reserved.
//

import UIKit

class FaceViewController:
        UIViewController{
    
    var expression = FaceExpression(eyes: .Open, eyeBrows: .Normal, mouth: .Smile)
    {
        didSet {
            updateUI()
        }
    }
    
    @IBOutlet weak var faceView: FaceView! {
        didSet {
            faceView.addGestureRecognizer(UIPinchGestureRecognizer(target: faceView, action: #selector(FaceView.changeScale(recognizer:))))
            let happierSwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(FaceViewController.increaseHappiness))
            let sedderSwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(FaceViewController.decreaseHappiness))
            
            happierSwipeGestureRecognizer.direction = .up
            faceView.addGestureRecognizer(happierSwipeGestureRecognizer)
            
            sedderSwipeGestureRecognizer.direction = .down
            faceView.addGestureRecognizer(sedderSwipeGestureRecognizer)
            updateUI()
        }
    }
    
    @objc func decreaseHappiness()
    {
        expression.mouth = expression.mouth.sadderMouth()
    }
    
    @objc func increaseHappiness()
    {
        expression.mouth = expression.mouth.happierMouth()
    }
    
    @IBAction func changeBrows(recognizer: UIRotationGestureRecognizer) {
        switch recognizer.state {
        case .ended, .changed:
            if recognizer.rotation > CGFloat(Double.pi / 4) {
                expression.eyeBrows = expression.eyeBrows.moreRelaxedBrow()
                recognizer.rotation = 0.0
            } else if recognizer.rotation < CGFloat(-Double.pi / 4) {
                expression.eyeBrows = expression.eyeBrows.moreFurrowedBrow()
                recognizer.rotation = 0.0
            }
        default:
            break
        }
    }
    
    @IBAction func toggleEyes(recognizer: UITapGestureRecognizer) {
        if recognizer.state == .ended {
            switch expression.eyes {
            case .Open : expression.eyes = .Closed
            case .Closed : expression.eyes = .Open
            case .Squinting: break
            }
        }
    }
    
    private var mouthCurvatures = [FaceExpression.Mouth.Frown: -1.0, .Grin: 0.5,
                                   .Smile: 1.0, .Smirk: -0.5, .Neutral: 0.0]
    
    private var eyeBrowTilts = [FaceExpression.EyeBrows.Furrowed: -0.5, .Normal: 0.0, .Relaxed: 0.5]
    
    private func updateUI() {
        if faceView != nil {
        switch expression.eyes {
        case .Open: faceView.eyesOPen = true
        case .Closed: faceView.eyesOPen = false
        case .Squinting: faceView.eyesOPen = false
        }
        
        faceView.mouthCurvature = mouthCurvatures[expression.mouth] ?? 0.0
        faceView.eyeBrowTilt = eyeBrowTilts[expression.eyeBrows] ?? 0.0
        }
    }
}

