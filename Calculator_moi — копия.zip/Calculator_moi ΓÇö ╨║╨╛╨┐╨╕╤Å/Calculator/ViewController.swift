//
//  ViewController.swift
//  Calculator
//
//  Created by Admin on 11.09.17.
//  Copyright © 2017 AdminVSU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @objc var userIsInTheMiddleOfTyping = false
    
    @IBAction func touchDigit(_ sender: UIButton) {
        
        let digit = sender.currentTitle!
        if userIsInTheMiddleOfTyping{
            let textCurrentlyInDisplay = display.text!
            display.text = textCurrentlyInDisplay + digit
        } else{
            display.text = digit
        }
        userIsInTheMiddleOfTyping = true
        
        
    }
    
    
    private var displayValue: Double?{
        get {
            return Double(display.text!)!
        }
        set {
            if let value=newValue {
                display.text=whithOutDot(digit: String(value))
                historyDisplay.text = (brain.description == "" ? "" : brain.description + (brain.isPartialResult ? " ..." : " ="))
            } else {
                display.text="0"
                historyDisplay.text = ""
                userIsInTheMiddleOfTyping = false
            }
        }
    }
    private func whithOutDot(digit: String)->String{
       
        let index=digit.index(of:".") ?? digit.endIndex
        let sub=String(digit[index..<digit.endIndex])
        
        if (sub == ".0"){
            return String(digit[digit.startIndex..<index]);
        }else{
            
            return digit
            
        }
        
        
    }
    
    @IBOutlet weak var historyDisplay: UILabel!
    
    private var newExpression=true
    
    @IBAction func clear(_ sender: UIButton) {
        historyDisplay.text=""
        displayValue=nil
        userIsInTheMiddleOfTyping = false
        brain.clear()
        presedM=false
        brain.clearVariableValues()
    }
    private var brain = CalculatorBrain()
    
    
    
    @IBAction func backSpace(_ sender: UIButton) {
        if(userIsInTheMiddleOfTyping){
        var s=display.text!
        if (s != "0"){
            s.remove(at : s.index(before: s.endIndex))
            if(s != "" && s[s.index(before: s.endIndex)]=="."){
                    s.remove(at : s.index(before: s.endIndex))
            }
        
        if(s=="" || s=="0" || s=="-0")
        {
            userIsInTheMiddleOfTyping=false
            s="0"
        }
            display.text=s;
            }}else
        {
            brain.undoLast()
            displayValue=brain.result;
        }
        
    }
    @IBAction private func perfomOperation(_ sender: UIButton) {
        
        if userIsInTheMiddleOfTyping{
            brain.setOperand(operand: displayValue!)
        }
        userIsInTheMiddleOfTyping = false
        if let mathematicalSymbol = sender.currentTitle{
            brain.perfomOperation(symbol: mathematicalSymbol)
        }
        
         displayValue = brain.result
       
    }
    
    @IBAction func undo(_ sender: UIButton) {
        brain.undoLast()
        displayValue=brain.result
        
        
        if (displayValue==0){
            userIsInTheMiddleOfTyping=false
        }
        
    }
    
    
    @IBAction func addDot(_ sender: UIButton) {
        if(display.text!.index(of:"." )==nil){
            display.text=display.text!+"."
            userIsInTheMiddleOfTyping=true
        }
    }
    @IBAction func setM(_ sender: UIButton) {
        userIsInTheMiddleOfTyping = false
        let symbol = String((sender.currentTitle!).characters.dropFirst())
        let value = displayValue
            brain.variableValues[symbol] = value
        displayValue=brain.result
        
        
    }
    
    var presedM=false;
    @IBAction func pushM(_ sender: UIButton) {
        brain.setOperand(variable: sender.currentTitle!)
        displayValue=brain.result
       
        
    }
    @IBOutlet private weak var display: UILabel!
    
}

