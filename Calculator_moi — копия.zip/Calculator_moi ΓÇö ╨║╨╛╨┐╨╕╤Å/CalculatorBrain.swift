//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Admin on 18.09.17.
//  Copyright © 2017 AdminVSU. All rights reserved.
//

import Foundation

class CalculatorBrain{
    private var accumulator = 0.0
    typealias PropertyList = AnyObject
    
    private var internalProgram = [AnyObject]()
    
    
    var program: PropertyList {
        get{
            return internalProgram as CalculatorBrain.PropertyList
            
        }
        
        set{
            clear()
            if let arrayOfOps=newValue as? [AnyObject]{
                for op in arrayOfOps {
                    if let operand = op as? Double{
                        setOperand(operand: operand)
                        
                    }else if let operation = op as? String{
                        if operations[operation] != nil {
                            
                            perfomOperation(symbol: operation)
                        } else {
                            
                            setOperand(variable: operation)
                        }
                    }
                }
            }
        }
    }
    
    func setOperand(operand: Double){
        if(operand != accumulator) || (isPartialResult){
            currentValue=whithOutDot(digit: String(operand))
        }
        internalProgram.append(operand as AnyObject)
        accumulator = operand
        
    }
    
    func undoLast() {
        guard !internalProgram.isEmpty  else { clear (); return }
        internalProgram.removeLast()
        program = internalProgram as CalculatorBrain.PropertyList
    }
    
    private func whithOutDot(digit: String)->String{
        
        let index=digit.index(of:".") ?? digit.endIndex
        let sub=String(digit[index..<digit.endIndex])
        
        if (sub == ".0"){
            return String(digit[digit.startIndex..<index]);
        }else{
            
            return digit
            
        }
  
    }
    
    private var operations: Dictionary<String, Operation> =
        [
        "Pi":Operation.Constant(Double.pi),
        "e":Operation.Constant(M_E),
        "√":Operation.UnaryOperation( sqrt),
        "cos":Operation.UnaryOperation(cos),
        "sin":Operation.UnaryOperation(sin),
        "tg":Operation.UnaryOperation(tan),
        "+/-":Operation.UnaryOperation({-$0}),
        "*":Operation.BinaryOperation({$0 * $1}),
        "+":Operation.BinaryOperation({$0 + $1}),
        "-":Operation.BinaryOperation({$0 - $1}),
        "/":Operation.BinaryOperation({$0 / $1}),
        "=": Operation.Equals,
        
        ]
    
    private enum Operation{
        case Constant(Double)
        case UnaryOperation((Double)->Double)
        case BinaryOperation((Double,Double)->Double)
        case Equals
        
    }
    public var description:String{
    get{
        
        
            return pastValue+currentValue
        
        
        }
        
   
    }
    private var currentValue:String = ""
    private var pastValue:String = ""
    var isPartialResult:Bool{
        get{
            
        return pending != nil
            }
    }
    
    
    var variableValues = [String:Double]() {
        didSet {
            
            program = internalProgram as CalculatorBrain.PropertyList
        }
    }
    
    func setOperand(variable: String) {
        accumulator = variableValues[variable] ?? 0
        currentValue=variable
        
        internalProgram.append(variable as AnyObject)
    }
    
    func perfomOperation (symbol: String)
    {
        internalProgram.append(symbol as AnyObject)
        
        if let operation = operations[symbol]{
            switch operation{
            case.Constant(let value): accumulator = value
                currentValue=symbol
            case.UnaryOperation(let function):
                currentValue=symbol+"("+currentValue+")"
                accumulator = function(accumulator)
                
            case.BinaryOperation(let function):
                pastValue = pastValue+currentValue+symbol
                currentValue=""
                executePendingBinaryOperation()
                pending = PendingBinaryOperationInfo(binaryFunction: function,firstOperand: accumulator)
                
            case.Equals:
                currentValue=pastValue+currentValue
                pastValue=""
                executePendingBinaryOperation()
            
            }
        }
    }
    
   
        
    private func executePendingBinaryOperation()
    {
        if pending != nil{accumulator = pending!.binaryFunction(pending!.firstOperand, accumulator)
            pending = nil}
    }
    public func clearVariableValues(){
        variableValues=[:]
    }
    func clear(){
        internalProgram.removeAll()
        accumulator = 0.0
        pending = nil
        currentValue=""
        pastValue=""
    }
    
    private var pending: PendingBinaryOperationInfo?
    
    private struct PendingBinaryOperationInfo {
        var binaryFunction:(Double, Double)->Double
        var firstOperand:Double
    }
    
    var result: Double{
        get{
            return accumulator
        }
    }
}
